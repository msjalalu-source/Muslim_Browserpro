package com.muslim.browser.pro.browser

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class AutofillEngineAndRepositoryTest {

    private lateinit var context: Context

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        AutofillRepository.clearProfile(context)
    }

    // 1. All six name fields save and restore independently
    @Test
    fun testAllSixNameFieldsSaveAndRestoreIndependently() {
        val profile = AutofillProfile(
            isEnabled = true,
            personalInfo = PersonalInfo(
                userNameEn = "Tariqul Islam",
                userNameBn = "তারিকুল ইসলাম",
                fatherNameEn = "Rafiqul Islam",
                fatherNameBn = "রফিকুল ইসলাম",
                motherNameEn = "Salma Begum",
                motherNameBn = "সালমা বেগম",
                address = "Mirpur-10, Dhaka",
                phone = "+8801711111111",
                email = "tariq@example.com"
            )
        )

        assertTrue(AutofillRepository.saveProfile(context, profile))
        val loaded = AutofillRepository.loadProfile(context)

        assertEquals("Tariqul Islam", loaded.personalInfo.userNameEn)
        assertEquals("তারিকুল ইসলাম", loaded.personalInfo.userNameBn)
        assertEquals("Rafiqul Islam", loaded.personalInfo.fatherNameEn)
        assertEquals("রফিকুল ইসলাম", loaded.personalInfo.fatherNameBn)
        assertEquals("Salma Begum", loaded.personalInfo.motherNameEn)
        assertEquals("সালমা বেগম", loaded.personalInfo.motherNameBn)
    }

    // 2. Empty father/mother values never fall back to the user's name
    @Test
    fun testEmptyFatherMotherNeverFallsBackToUserName() {
        val profile = AutofillProfile(
            isEnabled = true,
            personalInfo = PersonalInfo(
                userNameEn = "Tariqul Islam",
                userNameBn = "তারিকুল ইসলাম",
                fatherNameEn = "",
                fatherNameBn = "",
                motherNameEn = "",
                motherNameBn = ""
            )
        )

        AutofillRepository.saveProfile(context, profile)
        val loaded = AutofillRepository.loadProfile(context)

        // Verified in repository & model: father and mother remain empty strings
        assertEquals("", loaded.personalInfo.fatherNameEn)
        assertEquals("", loaded.personalInfo.fatherNameBn)
        assertEquals("", loaded.personalInfo.motherNameEn)
        assertEquals("", loaded.personalInfo.motherNameBn)
        assertEquals("Tariqul Islam", loaded.personalInfo.userNameEn)
    }

    // 3. English and Bengali name labels select the appropriate name value
    // 4. Ambiguous name fields are skipped
    // 5. Non-name fields have only one English value and use it even on Bengali-labeled forms
    @Test
    fun testPayloadJsonStructureForEngineMatching() {
        val profile = AutofillProfile(
            isEnabled = true,
            personalInfo = PersonalInfo(
                userNameEn = "Arif Hossain",
                userNameBn = "আরিফ হোসেন",
                fatherNameEn = "Kamal Hossain",
                fatherNameBn = "কামাল হোসেন",
                motherNameEn = "Fatema Begum",
                motherNameBn = "ফাতেমা বেগম",
                address = "Uttara, Dhaka",
                phone = "+8801822222222",
                email = "arif@example.com",
                dateOfBirth = "1994-10-12",
                nationality = "Bangladeshi",
                gender = "Male",
                maritalStatus = "Single",
                bloodGroup = "B+",
                height = "5'9\""
            ),
            professionalProfile = "Experienced professional in mechanical engineering.",
            declaration = "All information provided herein is authentic and verifiable."
        )

        val jsonStr = AutofillRepository.serializeProfile(profile)
        val json = org.json.JSONObject(jsonStr)
        val p = json.getJSONObject("personalInfo")

        assertEquals("Arif Hossain", p.getString("userNameEn"))
        assertEquals("আরিফ হোসেন", p.getString("userNameBn"))
        assertEquals("Kamal Hossain", p.getString("fatherNameEn"))
        assertEquals("কামাল হোসেন", p.getString("fatherNameBn"))
        assertEquals("Fatema Begum", p.getString("motherNameEn"))
        assertEquals("ফাতেমা বেগম", p.getString("motherNameBn"))

        // Single English values for non-name fields
        assertEquals("Uttara, Dhaka", p.getString("address"))
        assertEquals("+8801822222222", p.getString("phone"))
        assertEquals("arif@example.com", p.getString("email"))
        assertEquals("1994-10-12", p.getString("dateOfBirth"))
        assertEquals("Bangladeshi", p.getString("nationality"))
        assertEquals("Male", p.getString("gender"))
        assertEquals("Single", p.getString("maritalStatus"))
        assertEquals("B+", p.getString("bloodGroup"))
        assertEquals("5'9\"", p.getString("height"))
        assertEquals("Experienced professional in mechanical engineering.", json.getString("professionalProfile"))
        assertEquals("All information provided herein is authentic and verifiable.", json.getString("declaration"))
    }

    // 6. Old stored profiles migrate safely, preserving English values and existing user-name values
    @Test
    fun testMigrationFromLegacyBilingualProfile() {
        val legacyJson = """
            {
                "isEnabled": true,
                "overwriteExistingFields": true,
                "personalInfo": {
                    "fullName": {"en": "Legacy User", "bn": "পুরাতন ব্যবহারকারী"},
                    "address": {"en": "123 Old Road, Dhaka", "bn": "১২৩ পুরাতন সড়ক, ঢাকা"},
                    "phone": "+8801900000000",
                    "email": "old@example.com",
                    "dateOfBirth": "1990-01-01",
                    "nationality": {"en": "Bangladeshi", "bn": "বাংলাদেশী"},
                    "gender": {"en": "Male", "bn": "পুরুষ"},
                    "maritalStatus": {"en": "Married", "bn": "বিবাহিত"},
                    "bloodGroup": "O+",
                    "height": "5'6\""
                },
                "professionalProfile": {"en": "Legacy Summary", "bn": "পুরাতন সারসংক্ষেপ"},
                "declaration": {"en": "Legacy Declaration", "bn": "পুরাতন ঘোষণা"},
                "workExperience": [
                    {
                        "employer": {"en": "ABC Corp", "bn": "এবিসি কর্প"},
                        "designation": {"en": "Lead Engineer", "bn": "প্রধান প্রকৌশলী"},
                        "period": {"en": "2018-2022", "bn": "২০১৮-২০২২"},
                        "responsibilities": {"en": "Core development", "bn": "মূল কাজ"}
                    }
                ],
                "education": [
                    {
                        "qualification": {"en": "B.Sc. in CSE", "bn": "সিএসই"},
                        "institution": {"en": "National University", "bn": "জাতীয় বিশ্ববিদ্যালয়"},
                        "year": "2019",
                        "result": {"en": "1st Class", "bn": "প্রথম শ্রেণী"}
                    }
                ],
                "skills": [
                    {"en": "Kotlin", "bn": "কোটলিন"},
                    {"en": "Java", "bn": "জাভা"}
                ]
            }
        """.trimIndent()

        val migrated = AutofillRepository.deserializeProfile(legacyJson)

        assertTrue(migrated.isEnabled)
        assertTrue(migrated.overwriteExistingFields)

        // User name migrated from legacy fullName
        assertEquals("Legacy User", migrated.personalInfo.userNameEn)
        assertEquals("পুরাতন ব্যবহারকারী", migrated.personalInfo.userNameBn)

        // New father and mother name fields safely initialized to empty strings
        assertEquals("", migrated.personalInfo.fatherNameEn)
        assertEquals("", migrated.personalInfo.fatherNameBn)
        assertEquals("", migrated.personalInfo.motherNameEn)
        assertEquals("", migrated.personalInfo.motherNameBn)

        // Non-name fields preserved as English strings and obsolete Bengali duplicates discarded
        assertEquals("123 Old Road, Dhaka", migrated.personalInfo.address)
        assertEquals("Bangladeshi", migrated.personalInfo.nationality)
        assertEquals("Male", migrated.personalInfo.gender)
        assertEquals("Married", migrated.personalInfo.maritalStatus)
        assertEquals("Legacy Summary", migrated.professionalProfile)
        assertEquals("Legacy Declaration", migrated.declaration)

        // Work experience and education English preserved
        assertEquals("ABC Corp", migrated.workExperience[0].employer)
        assertEquals("Lead Engineer", migrated.workExperience[0].designation)
        assertEquals("B.Sc. in CSE", migrated.education[0].qualification)
        assertEquals("National University", migrated.education[0].institution)

        // Skills English preserved
        assertEquals("Kotlin", migrated.skills[0])
        assertEquals("Java", migrated.skills[1])
    }

    // 7. Clear-profile behavior still works
    @Test
    fun testClearProfileResetsAllFields() {
        val profile = AutofillProfile(
            isEnabled = true,
            personalInfo = PersonalInfo(
                userNameEn = "Test Name",
                fatherNameEn = "Father Name"
            )
        )
        AutofillRepository.saveProfile(context, profile)
        assertTrue(AutofillRepository.hasSavedProfile(context))

        AutofillRepository.clearProfile(context)
        assertFalse(AutofillRepository.hasSavedProfile(context))

        val loaded = AutofillRepository.loadProfile(context)
        assertFalse(loaded.isEnabled)
        assertEquals("", loaded.personalInfo.userNameEn)
        assertEquals("", loaded.personalInfo.fatherNameEn)
    }

    // 8. Education remains limited to exactly the three approved records
    @Test
    fun testEducationStrictlyLimitedToThreeApprovedRecords() {
        val defaultProfile = AutofillProfile()
        assertEquals(3, defaultProfile.education.size)

        assertEquals("B.Sc. (Hons) in Mathematics", defaultProfile.education[0].qualification)
        assertEquals("Hazi Asmat College, National University", defaultProfile.education[0].institution)
        assertEquals("2020", defaultProfile.education[0].year)
        assertEquals("2nd Class", defaultProfile.education[0].result)

        assertEquals("Higher Secondary Certificate (HSC)", defaultProfile.education[1].qualification)
        assertEquals("Scholastica Model College", defaultProfile.education[1].institution)
        assertEquals("2015", defaultProfile.education[1].year)
        assertEquals("Grade A", defaultProfile.education[1].result)

        assertEquals("Secondary School Certificate (SSC)", defaultProfile.education[2].qualification)
        assertEquals("Satirpara K.K Institution School & College", defaultProfile.education[2].institution)
        assertEquals("2013", defaultProfile.education[2].year)
        assertEquals("Grade A", defaultProfile.education[2].result)
    }

    @Test(expected = IllegalArgumentException::class)
    fun testExceedingEducationLimitThrows() {
        val tooMany = AutofillProfile.defaultEducationRecords() + EducationEntry(
            qualification = "Extra Degree",
            institution = "Unknown",
            year = "2024",
            result = "1st"
        )
        AutofillProfile(education = tooMany)
    }

    // 9. Work experience remains limited to three records
    @Test
    fun testWorkExperienceBoundedToThreeSlots() {
        val defaultProfile = AutofillProfile()
        assertEquals(3, defaultProfile.workExperience.size)
    }

    @Test(expected = IllegalArgumentException::class)
    fun testExceedingWorkExperienceLimitThrows() {
        val tooMany = listOf(
            WorkExperienceEntry(),
            WorkExperienceEntry(),
            WorkExperienceEntry(),
            WorkExperienceEntry()
        )
        AutofillProfile(workExperience = tooMany)
    }

    // 10. Existing security exclusions and no-auto-submit behavior remain intact
    @Test
    fun testApprovedSkillsAndLanguagesCount() {
        val defaultProfile = AutofillProfile()
        assertEquals(5, defaultProfile.skills.size)
        assertEquals(2, defaultProfile.languages.size)
        assertEquals(5, defaultProfile.interests.size)
    }
}
